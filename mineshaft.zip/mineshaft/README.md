# Bitcoin phpMiner

phpMiner uses CPU and it is slower than normal CPU miner. I didn't know it untill I made it, but that wasn't the goal. The goal was to be able to mine on server without much trouble and to run this on for example a webhost.

Run `test.php` for **testcase**.

Look in `work.php` for **example** how to use.

The proxy.php should have URI "/"

I am open for improvements and feedback.

## Usage

Via CLI:

Edit settings in `work.php` and run

	php work.php

or Via Browser:

Visit `work.php`-page

## Donate

Feel free to donate. `1NibBDZPvJCm568CZMnJUBJoPyUhW7aSag` This will keep me continue improving and updating, Thanks!

## Change log

2013-08-04 - **v1.0.1**

* Fix warning notices in PHP 5.5

2011-06-18 - **v1.0**

* First commit