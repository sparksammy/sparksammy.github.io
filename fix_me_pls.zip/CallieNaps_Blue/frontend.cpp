//CallieNaps Blue - Frontend/Backend Combo
//Made by Sparksammy
//See "LICENSE-CALINAPS_BLUE_FRONTEND" for license

#include <string.h>
#include <stdio.h>
#include <iostream>
#include "Bypass/bypass.h" //because this is great man.
#include "Lua/LuauTranspiler.h"

extern "C" {
	#include "Lua/lua.h"
	#include "Lua/lualib.h"
	#include "Lua/lauxlib.h"
}

using namespace std;

int main() {
	Bypass(); //Bypass ROBLOX stupid anticheat
	//Note to Sparksammy and devs: put your code below here.
	printf("loading exploit..."); //tell the user we are loading
	//create lua state
	lua_State *L;
	L = luaL_newstate();
	//open libs
	luaL_openlibs(L);
	//do stuff in LuauTranspiler
	LuauTranspiler::compile(L, "print('Hello, world! This is a test of Callinaps Blue.')");
	//Note to Sparksammy and devs: put your code above here.
	Restore(); //Undo bypass
}